<?php
error_reporting(0);

//cloor
   $Re = "\033[0m";
    $Bold       = "\033[1m";
    $Dim        = "\033[2m";
    $Ul = "\033[4m";
    $bk = "\e[5m";
    $Rv   = "\033[7m";
    $H     = "\033[8m";
    $ResetBold       = "\033[21m";
    $ResetDim        = "\033[22m";
    $ReUl = "\033[24m";
    $ResetBlink      = "\033[25m";
    $ResetReverse    = "\033[27m";
    $RH     = "\033[28m";
    $d      = "\033[39m";
    $b        = "\033[30m";
    $r          = "\033[31m";
    $g        = "\033[32m";
    $y       = "\033[33m";
    $bl         = "\033[34m";
    $m      = "\033[35m";
    $c         = "\033[36m";
    $lg    = "\033[37m";
    $dg     = "\033[90m";
    $lr     = "\033[91m";
    $lgr   = "\033[92m";
    $ly  = "\033[93m";
    $lbi    = "\033[94m";
    $lm = "\033[95m";
    $lc    = "\033[96m";
    $w       = "\033[97m";
    $BgD      = "\033[49m";
    $BgB        = "\033[40m";
    $BgR          = "\033[41m";
    $BgG = "\033[42m";
    $BgY       = "\033[43m";
    $BgBl         = "\033[44m";
    $BgM      = "\033[45m";
    $BgC       = "\033[46m";
    $BackgroundLightGray    = "\033[47m";
    $BackgroundDarkGray     = "\033[100m";
    $BackgroundLightRed     = "\033[101m";
    $BackgroundLightGreen   = "\033[102m";
    $BackgroundLightYellow  = "\033[103m";
    $BackgroundLightBlue    = "\033[104m";
    $BackgroundLightMagenta = "\033[105m";
    $BackgroundLightCyan    = "\033[106m";
    $BgW      = "\033[107m";



while (true){
	system ('clear');
	echo str_repeat("≈",40)."\n";
echo "÷ phP scripT herocaT [ autO referraL ]\n";
echo "÷ createD bY {$lgr}blacK_jeeN{$Re} forM BANGLADESH\n";
echo str_repeat("≈",40)."\n";
	
	
$url = "https://mobile.herocat.io/";

$ch = curl_init();

  curl_setopt($ch, CURLOPT_URL, $url);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_HEADER, 1);

  $response = curl_exec($ch);


$header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
  $headers = substr($response, 0, $header_size);
  curl_close($ch);

$a = explode('set-cookie: ', $headers);
$n = explode(';', $a[1]);
$coo2=$n[0];




//email

$ua1=array(
'Host: email-fake.com',
'sec-ch-ua: " Not A;Brand";v="99", "Chromium";v="100", "Google Chrome";v="100"',
'sec-ch-ua-mobile: ?1',
'sec-ch-ua-platform: "Android"',
'upgrade-insecure-requests: 1',
'user-agent: Mozilla/5.0 (Linux; Android 12; IN2015) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.58 Mobile Safari/537.36',
'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
'sec-fetch-site: none',
'sec-fetch-mode: navigate',
'sec-fetch-user: ?1',
'sec-fetch-dest: document',
'accept-language: en-US,en;q=0.9');



$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://email-fake.com/');
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, $ua1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
$result = curl_exec($ch);
$email=explode('</span>',explode('span id="email_ch_text">',$result)[1])[0];

echo "\r[+] neW emaiL : $email \n";
$email1="1 $email n";
$e1=explode('@',explode('1 ',$email1)[1])[0];
$e2=explode(' n',explode('@',$email)[1])[0];


$ua=array(
'Host: mobile.herocat.io',
'user-agent: Mozilla/5.0 (Linux; Android 12; IN2015) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.13 Mobile Safari/537.36',
'content-type: application/json; charset=UTF-8',
'accept: application/json, text/plain, */*',
'origin: https://mobile.herocat.io',
'referer: https://mobile.herocat.io/register',
'accept-language: en-US,en;q=0.9',
'cookie: '.$coo2.'',
'cookie: _ga=GA1.1.1550492415.1649970029',
'cookie: _ga_23QMW81014=GS1.1.1649970028.1.1.1649970048.0');

$scode="https://mobile.herocat.io/vcbank-api/msg/sendRegisterCode";


$data='{"email":"'.$email.'","phone":"","areaCode":"+65","type":"4","actionToken":"","randstr":"","targetType":2,"language":"en"}';
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $scode);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, $ua);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
$result = curl_exec($ch);
$json = json_decode($result);
$me1= $json-> code;

$ck2="200";
if ($me1==$ck2) {
  echo "[+] verificatioN codE senT \n";
  sleep (4);
} else {
  echo "\r [X] code not send Change your IP address \r";
  
  
}



$ua1=array(
'Host: email-fake.com',
'sec-ch-ua: " Not A;Brand";v="99", "Chromium";v="100", "Google Chrome";v="100"',
'sec-ch-ua-mobile: ?1',
'sec-ch-ua-platform: "Android"',
'upgrade-insecure-requests: 1',
'user-agent: Mozilla/5.0 (Linux; Android 12; IN2015) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.58 Mobile Safari/537.36',
'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
'sec-fetch-site: none',
'sec-fetch-mode: navigate',
'sec-fetch-user: ?1',
'sec-fetch-dest: document',
'accept-language: en-US,en;q=0.9',
'cookie: embx=%5B%22'.$email.'%22%5D',
'cookie: surl='.$e2.'/'.$e1.'');

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,'https://email-fake.com/');
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, $ua1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
$result = curl_exec($ch);

$code=explode('</h2>',explode('Your verification code is: </p><h2>',$result)[1])[0];


echo"[+] verificatioN codE : $code  \n";
$ua=array(
'Host: mobile.herocat.io',
'user-agent: Mozilla/5.0 (Linux; Android 12; IN2015) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.13 Mobile Safari/537.36',
'content-type: application/json; charset=UTF-8',
'accept: application/json, text/plain, */*',
'origin: https://mobile.herocat.io',
'referer: https://mobile.herocat.io/register',
'accept-language: en-US,en;q=0.9',
'cookie: '.$coo2.'',
'cookie: _ga=GA1.1.1550492415.1649970029',
'cookie: _ga_23QMW81014=GS1.1.1649970028.1.1.1649970048.0');

$scode="https://mobile.herocat.io/vcbank-api/auth/register";

$data='{"email":"'.$email.'","areaCode":"+65","phone":"","password":"ed388fbafe307f97a8538ae358bddf68","inviteCode":"s328059","registerCode":"'.$code.'","registerType":2}';

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $scode);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, $ua);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
$result = curl_exec($ch);
$me2=explode(',',explode('sendEmail" : ',$result)[1])[0];


$ck2="true";

if($me2==$ck2) {
  echo "[+] accounY creatE successfullY \n ";
 
$timer=rand(2,7);
for($time=$timer;$time>-1;$time--){
echo "\r".str_repeat(" ",30)." \r\r";
echo "\r[+] refreshinG afteR ".$time." secondS \r";
sleep(1);
}
} else {
  echo " [X] Account not Create Change your IP address\n";
 
 
}

}
